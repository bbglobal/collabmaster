
<?php $__env->startSection('title', 'Assign'); ?>

<?php $__env->startPush('plugin-styles'); ?>
    <link href="<?php echo e(asset('admin/assets/plugins/datatables-net-bs5/dataTables.bootstrap5.css')); ?>" rel="stylesheet" />
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-6 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">Assign</h4>
                    <br>
                    
                    <form id="signupForm" action="<?php echo e(route('admin.store.assign')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="ageSelect" class="form-label">SubAdmin</label>
                            <select class="form-select" name="subadmin_id" id="ageSelect" required>
                                <option selected disabled>Select your SubAdmin</option>
                                <?php $__currentLoopData = $subadmins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subadmin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($subadmin->id); ?>">
                                        <?php echo e($subadmin->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </select>
                            <span class="text-danger"><?php echo e($errors->first('subadmin_id')); ?></span>

                        </div>
                        <div class="mb-3">
                            <label for="name" class="form-label">Assign</label>
                            <input id="name" class="form-control" name="assign" type="text">
                            <span class="text-danger"><?php echo e($errors->first('assign')); ?></span>

                        </div>


                        <input class="btn btn-primary" type="submit" value="Submit">
                    </form>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('plugin-scripts'); ?>
    <script src="<?php echo e(asset('admin/assets/plugins/datatables-net/jquery.dataTables.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/plugins/datatables-net-bs5/dataTables.bootstrap5.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('custom-scripts'); ?>
    <script src="<?php echo e(asset('admin/assets/js/data-table.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/collabma/collabmaster/resources/views/admin/pages/assign/add.blade.php ENDPATH**/ ?>