
<?php $__env->startSection('title', 'SubAdmins'); ?>

<?php $__env->startPush('plugin-styles'); ?>
    <link href="<?php echo e(asset('assets/plugins/datatables-net-bs5/dataTables.bootstrap5.css')); ?>" rel="stylesheet" />
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-6 grid-margin stretch-card">
      <div class="card">
        <div class="card-body">
          <h4 class="card-title">Update SubAdmin</h4>
          <br>
          
          <form id="signupForm" action="<?php echo e(route('admin.update.subadmin')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="id" <?php if(!empty($subadmin)): ?> value="<?php echo e($subadmin->id); ?>" <?php endif; ?>>
            <div class="mb-3">
              <label for="name" class="form-label">Name</label>
              <input id="name" class="form-control" name="name" type="text"
              <?php if(!empty($subadmin)): ?> value="<?php echo e($subadmin->name); ?>" <?php endif; ?>>
              <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
            </div>
              <div class="mb-3">
                <label for="name" class="form-label">Email</label>
                <input id="name" class="form-control" name="email" type="text"
                <?php if(!empty($subadmin)): ?> value="<?php echo e($subadmin->email); ?>" <?php endif; ?>>
                <span class="text-danger"><?php echo e($errors->first('email')); ?></span>

              </div>
             
           
            
            <input class="btn btn-primary" type="submit" value="Update">
          </form>
        </div>
      </div>
    </div>
    
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('plugin-scripts'); ?>
    <script src="<?php echo e(asset('assets/plugins/datatables-net/jquery.dataTables.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatables-net-bs5/dataTables.bootstrap5.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('custom-scripts'); ?>
    <script src="<?php echo e(asset('assets/js/data-table.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\collabmaster\resources\views/admin/pages/subadmin/edit.blade.php ENDPATH**/ ?>