

<?php $__env->startPush('footer-style'); ?>
    <style>
        .nk-footer {
            display: none;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main-section'); ?>
    <?php if($message = Session::get('message')): ?>
        <div id="msg-holder">
            <div id="msg-holder-row">
                <img src="https://d5ik1gor6xydq.cloudfront.net/websiteImages/creatorMarketplace/err.svg" id="msg-img-err"
                    class="succ-err-msg-img">
                <div id="msg"><?php echo e($message); ?></div>
            </div>
        </div>
    <?php endif; ?>
    <div class="nk-content main-outer-container">
        <div class="container-fluid">
            <div class="nk-content-inner">
                <div class="nk-content-body">
                    <div class="nk-content-wrap">


                        <div class="nk-block nk-block-middle nk-auth-body wide-xs pt-0">
                            
                            <div class="card mt-5">
                                <div class="card-inner card-inner p-0">
                                    <div class="top-btn-holder">
                                        
                                        <div class="step-holder">9/9</div>
                                    </div>
                                    <div class="nk-block-head">
                                        <div class="nk-block-head-content">
                                            <h3 class="nk-block-title"><b>Add Your Mobile Number</b></h3>
                                        </div>
                                    </div>

                                    <form method="POST" action="<?php echo e(route('create.page', ['id' => 10])); ?>" id="form">
                                        <?php echo csrf_field(); ?>
                                        <div class="form-group mb-3">
                                            <input id="phone" type="text" class="form-control form-control-lg"
                                                name="phone_number" autofocus placeholder="Phone Number" required>
                                        </div>
                                        <div class="form-group mb-3">
                                            <button type="submit" class="btn btn-lg btn-secondary btn-block"
                                                id="primary">Continue</button>

                                            <button class="btn btn-lg btn-secondary btn-block d-none" id="loading"
                                                type="button" disabled>
                                                <span class="spinner-border spinner-border-sm" role="status"
                                                    aria-hidden="true"></span>
                                                <span>Loading...</span>
                                            </button>
                                        </div>
                                    </form>

                                    
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- content @e -->

    <script>
        $(document).ready(function() {
            $('#form').submit(() => {
                $('#primary').addClass("d-none");
                $("#loading").removeClass("d-none")
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\collabmaster\resources\views/creator/phone.blade.php ENDPATH**/ ?>