
<?php $__env->startPush('title'); ?>
    <title>Students</title>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('admin-section'); ?>
    <!-- Header Layout Content -->
    <div class="mdk-header-layout__content mdk-header-layout__content--fullbleed mdk-header-layout__content--scrollable page"
        style="padding-top: 60px;">


        <div class="page__heading border-bottom">
            <div class="container-fluid page__container d-flex align-items-center">
                <h1 class="mb-0">Students</h1>
                
            </div>
        </div>

        <div class="container-fluid page__container">

            <div class="card card-form">
                <div class="row no-gutters">
                    <div class="col-lg-12 card-form__body">

                        <div class="table-responsive border-bottom" data-toggle="lists"
                            data-lists-values='["js-lists-values-employee-name"]'>

                            <div class="search-form search-form--light m-3">
                                <input type="text" id="searchInput" class="form-control search" placeholder="Search">
                                <button class="btn" type="button"><i class="material-icons">search</i></button>
                            </div>

                            <table class="table mb-0 thead-border-top-0">
                                <thead>
                                    <tr>
                                        <th>Id</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Contact</th>
                                        <th>Course</th>
                                        <th>Fee Status</th>
                                        <th>Registered On</th>
                                        <th>Updated On</th>
                                    </tr>
                                </thead>
                                <tbody class="list" id="staff02">
                                    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <span><?php echo e($row->id); ?></span>
                                            </td>
                                            <td>
                                                <span class="js-lists-values-employee-name"><?php echo e($row->name); ?></span>
                                            </td>
                                            <td>
                                                <span class="js-lists-values-employee-name">
                                                    <a href="mailto:<?php echo e($row->email); ?>"
                                                        style="color: #000;"><?php echo e($row->email); ?></a>
                                                </span>
                                            </td>
                                            <td>
                                                <span class="js-lists-values-employee-name"><?php echo e($row->contact); ?></span>
                                            </td>
                                            <td>
                                                <?php if($row->title === null): ?>
                                                    <span class="badge badge-warning">
                                                        Not Enrolled
                                                    </span>
                                                <?php else: ?>
                                                    <span class="badge badge-primary">
                                                        <?php echo e($row->title); ?>

                                                    </span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if($row->title === null): ?>
                                                    <span class="badge badge-danger">
                                                        Not Paid
                                                    </span>
                                                <?php else: ?>
                                                    <span class="badge badge-success">
                                                        Paid
                                                    </span>
                                                <?php endif; ?>
                                            </td>
                                            <td><small class="text-muted"><?php echo e($row->created_at); ?></small></td>
                                            <td><small class="text-muted"><?php echo e($row->updated_at); ?></small></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>


    </div>
    <!-- // END header-layout__content -->

    </div>
    <!-- // END header-layout -->

    </div>
    <!-- // END drawer-layout__content -->

    <?php if (isset($component)) { $__componentOriginal5dbcd2c5f624951ffc95c729c55bdb11 = $component; } ?>
<?php $component = App\View\Components\AdminSidebar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminSidebar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5dbcd2c5f624951ffc95c729c55bdb11)): ?>
<?php $component = $__componentOriginal5dbcd2c5f624951ffc95c729c55bdb11; ?>
<?php unset($__componentOriginal5dbcd2c5f624951ffc95c729c55bdb11); ?>
<?php endif; ?>
    </div>
    <script>
        // Get the input element and table body
        var input = document.getElementById("searchInput");
        var tableBody = document.getElementById("staff02");

        // Add an event listener to the search input
        input.addEventListener("input", function() {
            var searchQuery = input.value.toLowerCase();

            // Get all rows in the table
            var rows = tableBody.getElementsByTagName("tr");

            // Loop through the rows and hide those that don't match the search query
            for (var i = 0; i < rows.length; i++) {
                var row = rows[i];
                var cells = row.getElementsByTagName("td");
                var found = false;

                for (var j = 0; j < cells.length; j++) {
                    var cell = cells[j];
                    if (cell) {
                        var text = cell.innerText.toLowerCase();
                        if (text.indexOf(searchQuery) > -1) {
                            found = true;
                            break;
                        }
                    }
                }

                if (found) {
                    row.style.display = "";
                } else {
                    row.style.display = "none";
                }
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\taskministries\resources\views/admin/students.blade.php ENDPATH**/ ?>