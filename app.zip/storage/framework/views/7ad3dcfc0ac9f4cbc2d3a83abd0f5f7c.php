<nav class="sidebar">
  <div class="sidebar-header">
    <a href="#" class="sidebar-brand">
      Collabmaster<span></span>
    </a>
    <div class="sidebar-toggler not-active">
      <span></span>
      <span></span>
      <span></span>
    </div>
  </div>
  <div class="sidebar-body">
    <ul class="nav">
      <li class="nav-item nav-category">Main</li>
      <li class="nav-item">
        <a href="<?php echo e(route('admin.dashboard')); ?>" class="nav-link">
          <i class="link-icon" data-feather="box"></i>
          <span class="link-title">Dashboard</span>
        </a>
      </li>

      <li class="nav-item nav-category">Components</li>

      <li class="nav-item">
        <a href="<?php echo e(route('admin.add.staff')); ?>" class="nav-link">
          <i class="link-icon" data-feather="box"></i>
          <span class="link-title">Staff</span>
        </a>
      </li>

      <li class="nav-item">
        <a href="<?php echo e(route('admin.subadmin')); ?>" class="nav-link">
          <i class="link-icon" data-feather="box"></i>
          <span class="link-title">SubAdmin</span>
        </a>
      </li>

      <li class="nav-item">
        <a href="<?php echo e(route('admin.assign')); ?>" class="nav-link">
          <i class="link-icon" data-feather="box"></i>
          <span class="link-title">Assign</span>
        </a>
      </li>

      <li class="nav-item">
        <a href="<?php echo e(route('admin.brand')); ?>" class="nav-link">
          <i class="link-icon" data-feather="box"></i>
          <span class="link-title">Brands</span>
        </a>
      </li>

      <li class="nav-item">
        <a href="<?php echo e(route('admin.creator')); ?>" class="nav-link">
          <i class="link-icon" data-feather="box"></i>
          <span class="link-title">Creators</span>
        </a>
      </li>

      <li class="nav-item">
        <a href="<?php echo e(route('admin.order')); ?>" class="nav-link">
          <i class="link-icon" data-feather="box"></i>
          <span class="link-title">Orders</span>
        </a>
      </li>

      <li class="nav-item">
        <a href="<?php echo e(route('admin.invoices')); ?>" class="nav-link">
          <i class="link-icon" data-feather="box"></i>
          <span class="link-title">Invoices</span>
        </a>
      </li>



      
      
    </ul>
  </div>
</nav>
<nav class="settings-sidebar">
  <div class="sidebar-body">
    <a href="#" class="settings-sidebar-toggler">
      <i data-feather="settings"></i>
    </a>
    <div class="theme-wrapper">
      <h6 class="text-muted mb-2">Light Version:</h6>
      <a class="theme-item" href="https://www.nobleui.com/laravel/template/demo1/">
        <img src="<?php echo e(url('assets/images/screenshots/light.jpg')); ?>" alt="light version">
      </a>
      <h6 class="text-muted mb-2">Dark Version:</h6>
      <a class="theme-item active" href="https://www.nobleui.com/laravel/template/demo2/">
        <img src="<?php echo e(url('assets/images/screenshots/dark.jpg')); ?>" alt="light version">
      </a>
    </div>
  </div>
</nav>
<?php /**PATH D:\xampp\htdocs\collab\resources\views/admin/layout/sidebar.blade.php ENDPATH**/ ?>