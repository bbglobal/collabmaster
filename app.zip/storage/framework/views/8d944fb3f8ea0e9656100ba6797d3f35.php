<?php $__env->startPush('title'); ?>
    <title>Instructors Dashboard</title>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('admin-section'); ?>
    <!-- Header Layout Content -->
    <div class="mdk-header-layout__content mdk-header-layout__content--fullbleed mdk-header-layout__content--scrollable page"
        style="padding-top: 60px;">
    </div>
    <!-- // END header-layout__content -->

    </div>
    <!-- // END header-layout -->

    </div>
    <!-- // END drawer-layout__content -->

    <?php if (isset($component)) { $__componentOriginal652ab7bc66b9ed44ea5d06dac129feb9 = $component; } ?>
<?php $component = App\View\Components\TeacherSidebar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('teacher-sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\TeacherSidebar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal652ab7bc66b9ed44ea5d06dac129feb9)): ?>
<?php $component = $__componentOriginal652ab7bc66b9ed44ea5d06dac129feb9; ?>
<?php unset($__componentOriginal652ab7bc66b9ed44ea5d06dac129feb9); ?>
<?php endif; ?>
    </div>
    <!-- // END drawer-layout -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\taskministries\resources\views/teacher/teacher-dashboard.blade.php ENDPATH**/ ?>