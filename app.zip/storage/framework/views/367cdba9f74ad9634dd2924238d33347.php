
<?php $__env->startSection('title', 'Creators'); ?>

<?php $__env->startPush('plugin-styles'); ?>
    <link href="<?php echo e(asset('admin/assets/plugins/datatables-net-bs5/dataTables.bootstrap5.css')); ?>" rel="stylesheet" />
<?php $__env->stopPush(); ?>



<?php $__env->startSection('content'); ?>
    <nav class="page-breadcrumb">
        
        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>
    </nav>




    <div class="row">

        
        <div class="col-md-12 grid-margin stretch-card">

            <div class="card">
                <div class="card-body">
                    <h6 class="card-title">Creators</h6>
                    <p class="text-muted mb-3"><a href="https://datatables.net/" target="_blank"></a></p>
                    <div class="table-responsive">
                        <table id="dataTableExample" class="table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Full Name</th>
                                    <th>Brand Name</th>
                                    <th>Email</th>
                                    <th>Phone Number</th>
                                    <th>Found Us</th>
                                    <th>Role</th>
                                    <th>Status</th>

                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $creators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $creator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($creator->id); ?></td>
                                        <td><?php echo e($creator->full_name); ?></td>
                                        <td><?php echo e($creator->brand_name); ?></td>
                                        <td><?php echo e($creator->email); ?></td>
                                        <td><?php echo e($creator->phone_number); ?></td>
                                        <td><?php echo e($creator->found_us); ?></td>
                                        <td><?php echo e($creator->role); ?></td>
                                        <td>
                                            <?php if($creator->status == 'Active'): ?>
                                            <span class="text-success">
                                                Active
                                            </span>
                                            <?php else: ?>
                                            <span class="text-danger">
                                                DeActive
                                            </span>
                                            <?php endif; ?>
                                         </td>

                                        <td> 
                                            <a class="edit"
                                                href="<?php echo e(route('admin.creator.status',['id'=>$creator->id])); ?>">
                                                <i class="link-icon" data-feather="edit"></i>

                                            </a>

                                            <a class="edit"
                                                href="<?php echo e(route('admin.creator.details',['id'=>$creator->id])); ?>">
                                                <i class="link-icon" data-feather="eye"></i>

                                            </a>
                                            
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('plugin-scripts'); ?>
    <script src="<?php echo e(asset('admin/assets/plugins/datatables-net/jquery.dataTables.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/plugins/datatables-net-bs5/dataTables.bootstrap5.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('custom-scripts'); ?>
    <script src="<?php echo e(asset('admin/assets/js/data-table.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\collab\resources\views/admin/pages/user/creator_table.blade.php ENDPATH**/ ?>