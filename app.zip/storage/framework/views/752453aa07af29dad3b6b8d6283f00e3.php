
<?php $__env->startPush('title'); ?>
    <title>Edit Instructors</title>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('admin-section'); ?>
    <!-- Header Layout Content -->
    <div class="mdk-header-layout__content mdk-header-layout__content--fullbleed mdk-header-layout__content--scrollable page"
        style="padding-top: 60px;">


        <div class="page__heading border-bottom">
            <div class="container-fluid page__container d-flex align-items-center">
                <h1 class="mb-0">Edit Instructor</h1>
            </div>
        </div>

        <div class="container-fluid page__container">
            <?php if($message = Session::get('success')): ?>
                <div class="alert alert-soft-success d-flex" role="alert">
                    <i class="material-icons mr-3">check_circle</i>
                    <div class="text-body">
                        <?php echo e($message); ?>

                    </div>
                </div>
            <?php endif; ?>
            <div class="card card-form">
                <div class="row no-gutters">
                    <div class="col-lg-12 card-form__body card-body">
                        <form method="post" action="<?php echo e($url); ?>" class="row">
                            <?php echo csrf_field(); ?>
                            <div class="form-group col-6">
                                <label for="fname">First Name:</label>
                                <input type="text" name="first_name" class="form-control" id="fname"
                                    placeholder="Frist Name" value="<?php echo e($teacher->first_name); ?>">
                            </div>
                            <div class="form-group col-6">
                                <label for="lname">Last Name:</label>
                                <input type="text" name="last_name" class="form-control" id="lname"
                                    placeholder="Last Name" value="<?php echo e($teacher->last_name); ?>">
                            </div>
                            <div class="form-group col-6">
                                <label for="email">Email:</label>
                                <input type="email" name="email" class="form-control" id="email"
                                    placeholder="Enter email address .." value="<?php echo e($teacher->email); ?>">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                            </div>
                            <div class="form-group col-6">
                                <label for="contact">Contact:</label>
                                <input type="text" name="contact" class="form-control" id="contact"
                                    placeholder="Contact Number .." value="<?php echo e($teacher->contact); ?>">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['contact'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                <span class="text-danger">
                            </div>
                            <div class="form-group col-6">
                                <label for="password">Password:</label>
                                <input type="password" name="password" class="form-control" id="password"
                                    placeholder="Enter password .." value="<?php echo e($teacher->password); ?>">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                            </div>
                            <div class="form-group col-6">
                                <label for="class">Role:</label>
                                <input type="text" name="level" class="form-control" id="course"
                                    placeholder="Add a Role .." value="<?php echo e($teacher->level); ?>">
                            </div>
                            <button type="submit" class="btn btn-success"><i class="material-icons">edit</i>Update
                                Teacher</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>


    </div>
    <!-- // END header-layout__content -->

    </div>
    <!-- // END header-layout -->

    </div>
    <!-- // END drawer-layout__content -->

    <?php if (isset($component)) { $__componentOriginal5dbcd2c5f624951ffc95c729c55bdb11 = $component; } ?>
<?php $component = App\View\Components\AdminSidebar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminSidebar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5dbcd2c5f624951ffc95c729c55bdb11)): ?>
<?php $component = $__componentOriginal5dbcd2c5f624951ffc95c729c55bdb11; ?>
<?php unset($__componentOriginal5dbcd2c5f624951ffc95c729c55bdb11); ?>
<?php endif; ?>
    </div>
    <!-- // END drawer-layout -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\taskministries\resources\views/admin/edit-teacher.blade.php ENDPATH**/ ?>