<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Order;
use PDF;

class OrderController extends Controller
{
    //
    public function order_view(){
        $orders = Order::all();
        return view('admin.pages.order.table',compact('orders'));
    }

    public function invoice_view(){
        $orders = Order::all();
        return view('admin.pages.invoice.table',compact('orders'));
    }

    public function order_view_invoice($id)
    {
        $order = Order::find($id);
        return view('admin.pages.order.invoice',compact('order'));
    }
}
