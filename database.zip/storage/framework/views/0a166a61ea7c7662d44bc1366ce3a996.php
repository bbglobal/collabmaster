

<?php $__env->startSection('main-section'); ?>
    <div class="banner-wrapper py-5 my-5">

        <div class="banner">
            <div class="container">
                <figure>
                    <img src="<?php echo e(url('assets/images/logos/contact-img.png')); ?>" alt="image" width="100%">
                </figure>
            </div>

            
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\taskministries\resources\views/index.blade.php ENDPATH**/ ?>