

<?php $__env->startPush('title'); ?>
    <title>Contact</title>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main-section'); ?>
    <section id="about">
        <div class="container py-5">
            <div class="col-12 text-center head">
                <h1>CONTACT US</h1>
            </div>
            <?php if($message = Session::get('success')): ?>
                <div class="alert alert-info alert-dismissible fade show" role="alert">
                    <strong>Thank You</strong> <?php echo e($message); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            <div class="row py-5">
                <div class="col-12 col-md-12 col-lg-6 text-center" style="margin: auto;">
                    <img src="<?php echo e(url('assets/images/logos/contact-img.png')); ?>" alt="image" width="100%">
                </div>
                <form method="post" action="<?php echo e(route('admin.add')); ?>" class="col-12 col-md-12 col-lg-6">
                    <?php echo csrf_field(); ?>
                    <h3>GET IN TOUCH</h3>
                    <div class="mb-3 mt-3 col-12">
                        <input type="name" class="form-control" id="name" placeholder="Name" name="name"
                            value="<?php echo e(old('name')); ?>">
                        <div class="text-danger">
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php echo e($message); ?>

                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="mb-3 mt-3 col-12">
                        <input type="email" class="form-control" id="email" placeholder="Eamil" name="email"
                            value="<?php echo e(old('email')); ?>">
                        <div class="text-danger">
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php echo e($message); ?>

                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="mb-3 mt-3 col-12">
                        <input type="number" class="form-control" id="number" placeholder="Number" name="contact"
                            value="<?php echo e(old('contact')); ?>">
                        <div class="text-danger">
                            <?php $__errorArgs = ['contact'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php echo e($message); ?>

                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="mb-3 mt-3">
                        <textarea name="message" id="message" placeholder="Message" cols="30" rows="10" class="form-control"></textarea>
                    </div>
                    <button class="btn-task">
                        Submit
                    </button>
                </form>
            </div>
        </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\taskministries\resources\views/contact.blade.php ENDPATH**/ ?>