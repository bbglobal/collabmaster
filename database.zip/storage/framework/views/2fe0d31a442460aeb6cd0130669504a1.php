

<?php $__env->startPush('title'); ?>
    <title>Category</title>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main-section'); ?>
    <section id="browse-each">
        <div class="col-12 text-center cat-head browse-each">
            <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <figure>
                    <img src="<?php echo e(url('assets/images/' . $row->course_image)); ?>" alt="image" width="100%" height="450px">
                </figure>
        </div>
        <div class="browse-container container">
            <div class="row">
                <div class="col-12 col-md-12 col-lg-2 py-5">
                    <button class="btn-task">
                        <a href="">
                            Register
                        </a>
                    </button>
                </div>
                <div class="col-12 col-md-12 col-lg-10 py-5">
                    <div class="d-flex align-items-center justify-content-between">
                        <p>
                            <?php echo e($row->title); ?>

                        </p>
                        <p>
                            <strong>&dollar;<?php echo e($row->fee); ?></strong>
                        </p>
                    </div>
                    <div class="py-2">
                        <small>with <i class="fa fa-user"></i> <?php echo e($row->level); ?> <?php echo e($row->first_name); ?>

                            <?php echo e($row->last_name); ?></small>
                    </div>
                    <p>
                        <strong>
                            <?php echo e($row->sub_title); ?>

                        </strong>
                    </p>
                    <p>
                        <?php echo e($row->description); ?>

                    </p>
                    <p>
                        <a href="<?php echo e($row->link); ?>">Material</a>
                    </p>
                    <div>
                        <div class="calendar-graphic">
                            <div class="month">Aug</div>
                            <div class="date">7</div>
                        </div>
                        <div class="calendar-date">
                            <div class=""><?php echo e($row->start_date); ?> - <?php echo e($row->end_date); ?></div>
                            <div class="">7</div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\taskministries\resources\views/category.blade.php ENDPATH**/ ?>