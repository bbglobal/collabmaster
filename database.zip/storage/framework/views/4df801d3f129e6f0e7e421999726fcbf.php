<footer class="footer d-flex flex-column flex-md-row align-items-center justify-content-between px-4 py-3 border-top small">
  <p class="text-muted mb-1 mb-md-0">Copyright © 2024 <a href="#" target="_blank">Collabster</a>.</p>
  
</footer><?php /**PATH /home/collabma/collabmaster/resources/views/admin/layout/footer.blade.php ENDPATH**/ ?>