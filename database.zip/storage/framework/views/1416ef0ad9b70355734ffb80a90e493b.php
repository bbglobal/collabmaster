﻿

<?php $__env->startPush('footer-style'); ?>
    <style>
        .profile-img {
            position: relative;
            height: 20px;
            width: 20px;
            object-fit: cover;
            border-radius: 50%;
        }

        .package-filter-holder {
            display: flex;
            margin-bottom: 3%;
            width: fit-content;
            max-width: 100%;
            border-radius: 8px;
            font-size: 96%;
        }

        .package-filter {
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100%;
            padding: 8px;
            color: gray;
            cursor: pointer;
            font-weight: 600;
            transition-duration: 0.3s;
            white-space: nowrap;
            border-radius: 8px;
            min-width: 90px;
            background-color: rgb(243, 243, 243);
            margin-right: 10px;
        }

        .package-filter-active,
        .package-filter:hover {
            color: white;
            background-color: var(--collabstrDark);
            background: var(--gradientText);
        }

        .msg-btn-holder a {
            color: #000;
        }

        .msg-btn-holder a:hover {
            text-decoration: underline;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main-section'); ?>

    <!-- content @s
        -->
        <div class="nk-content main-outer-container mt-0">
            <div class="container-fluid">
                <div class="nk-content-inner">
                    <div class="nk-content-body">
                        <div class="nk-content-wrap">
                            <div class="nk-block-head nk-block-head-lg">
                                <div class="btn-row btn-row-mobile">
                                    <div class="share-btn row-btn">
                                        <img class="row-btn-img row-btn-img-mobile"
                                            src="<?php echo e(url('assets/websiteImages/creatorMarketplace/share.svg')); ?>"
                                            alt="share button">
                                        <span class="row-btn-txt">Share</span>
                                    </div>
                                    <div class="save-btn row-btn" data-id="save">
                                        <svg class="row-btn-img row-btn-img-mobile row-btn-save-img " viewbox="0 0 32 32">
                                            <path
                                                d="m16 28c7-4.733 14-10 14-17 0-1.792-.683-3.583-2.05-4.95-1.367-1.366-3.158-2.05-4.95-2.05-1.791 0-3.583.684-4.949 2.05l-2.051 2.051-2.05-2.051c-1.367-1.366-3.158-2.05-4.95-2.05-1.791 0-3.583.684-4.949 2.05-1.367 1.367-2.051 3.158-2.051 4.95 0 7 7 12.267 14 17z">
                                            </path>
                                        </svg>
                                        <span class="save-btn-txt row-btn-txt">Save</span>
                                    </div>
                                </div>
                                <div class="listing-img">
                                    <div class="img-row">
                                        <div class="primary-img">
                                            <div class="file-area">
                                                <picture>

                                                    <img fetchpriority="high" class="img img1 zoom-in-image" data-toggle="modal"
                                                        data-target="#open-image-modal"
                                                        src="<?php echo e(url('assets/images/' . $creator->img_1)); ?>" alt="image">
                                                </picture>
                                            </div>
                                        </div>
                                        <div class="img-col">
                                            <div class="img-row-sq">
                                                <div class="file-area">
                                                    <picture>

                                                        <img class="img img2 zoom-in-image" data-toggle="modal"
                                                            data-target="#open-image-modal"
                                                            src="<?php echo e(url('assets/images/' . $creator->img_2)); ?>"
                                                            alt="Photo of Dalena">
                                                    </picture>
                                                </div>
                                                <div class="file-area">
                                                    <picture>

                                                        <img class="img img3 zoom-in-image" data-toggle="modal"
                                                            data-target="#open-image-modal"
                                                            src="<?php echo e(url('assets/images/' . $creator->img_3)); ?>"
                                                            alt="Photo of Dalena">
                                                    </picture>
                                                </div>
                                            </div>
                                            <div class="file-area file-area4">
                                                <picture>

                                                    <img class="img img4 zoom-in-image" data-toggle="modal"
                                                        data-target="#open-image-modal"
                                                        src="<?php echo e(url('assets/images/' . $creator->img_4)); ?>"
                                                        alt="Photo of Dalena">
                                                </picture>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="profile-holder">
                                        <img loading="lazy" class="profile-pic"
                                            src="<?php echo e(url('assets/images/' . $creator->file_path)); ?>" alt="Photo of Dalena">
                                        <div class="profile-info-holder">
                                            <h1 class="listing-title"><?php echo e($creator->full_name); ?> | <?php echo e($creator->bio); ?></h1>
                                            <div class="profile-name-location">
                                                <?php echo e($creator->location); ?>

                                            </div>
                                            <div class="profile-img-holder">
                                                <div class="profile-img">
                                                    <img loading="lazy"
                                                        src="<?php echo e(url('assets/websiteImages/creatorMarketplace/instagram.svg')); ?>"
                                                        alt="Instagram logo">
                                                </div>
                                                <div class="profile-img">
                                                    <img loading="lazy"
                                                        src="<?php echo e(url('assets/websiteImages/creatorMarketplace/tiktok.svg')); ?>"
                                                        alt="TikTok logo">
                                                </div>
                                                <div class="profile-img">
                                                    <img loading="lazy"
                                                        src="<?php echo e(url('assets/websiteImages/creatorMarketplace/youtube.svg')); ?>"
                                                        alt="YouTube logo">
                                                </div>
                                            </div>
                                        </div>
                                    </div>


                                    

                                    <div class="listing-description mb-5"><?php echo e($creator->description); ?></div>

                                    <div class="nk-block-head pb-0">
                                        <div class="nk-block-head-content section-title pb-0">
                                            <h4 class="title nk-block-title">Packages</h4>
                                            <div class="how-it-works-btn">
                                                <img loading="lazy" alt="How Collabstr works" class="how-it-works-btn-img"
                                                    src="<?php echo e(url('assets/websiteImages/creatorMarketplace/howItWorks.svg')); ?>">
                                                How does it work?
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card">
                                        <div class="card-inner p-0">

                                            

                                            <div class="package-filter-holder">
                                                <div class="package-filter package-filter-active" data-platform="all">All</div>
                                            </div>

                                            <div class="tab-content">
                                                <div class="tab-pane active" id="tab-all">
                                                    <div class="row">
                                                        <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <div class="col-sm-12 col-md-6 col-lg-6 mb-3">
                                                                <div class="package-holder"
                                                                    data-platform="<?php echo e($package->package_content_type_); ?>">
                                                                    <!-- Your content here -->

                                                                    <div class="package-top-row">
                                                                        <div class="package-title">
                                                                            <?php echo e($package->package_quantity_); ?>

                                                                            <?php echo e($package->package_content_type_); ?>

                                                                            <?php if($package->package_duration_ != null): ?>
                                                                                (<?php echo e($package->package_duration_); ?>

                                                                                <?php echo e($package->package_duration_unit_); ?>)
                                                                            <?php endif; ?>
                                                                        </div>
                                                                        <div class="package-price">
                                                                            ₹<?php echo e($package->package_price_); ?>

                                                                        </div>
                                                                    </div>
                                                                    <div class="package-desc">
                                                                        <?php echo e($package->package_description_); ?>

                                                                        <span class="see-more-package">See More</span>
                                                                    </div>
                                                                    <div style="display: none" class="package-desc-full">This
                                                                        offer includes one Instagram story post which will be
                                                                        advertised to my audience. The Instagram story views
                                                                        average around 2000-6000 views per upload.</div>
                                                                    <div class="package-btm-row">
                                                                        <div
                                                                            class="package-img-holder package-img-holder-instagram">
                                                                            <img class="package-img"
                                                                                src="<?php echo e(url('assets/websiteImages/creatorMarketplace/instagram.svg')); ?>"
                                                                                alt="Instagram logo" loading="lazy">
                                                                        </div>
                                                                        <a href="<?php echo e(route('brand.checkout', ['id' => $package->id])); ?>"
                                                                            class="buy-btn btn">Continue</a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                    </div><!-- .card-preview -->

                                    <div class="msg-btn-holder">Have a different request?
                                        <a href="<?php echo e(route('offer.create', ['id' => $creator->user_id])); ?>" class="msg-btn">Send a
                                            Custom Offer</a>
                                    </div>



                                    

                                    <!--<div class="related-cats-holder">-->
                                    <!--    <h3 class="related-cats-title">Related Categories</h3>-->
                                    <!--    <div class="related-items-holder">-->
                                    <!--        <a class="related-item" href="/find-influencers/instagram" target="_blank">Find-->
                                    <!--            Instagram Influencers</a>-->
                                    <!--        <a class="related-item" href="/find-influencers/tiktok" target="_blank">Find-->
                                    <!--            TikTok Influencers</a>-->
                                    <!--        <a class="related-item" href="/find-influencers/health-&-fitness"-->
                                    <!--            target="_blank">Find Health &amp; Fitness Influencers</a>-->
                                    <!--        <a class="related-item" href="/find-influencers/music-&-dance"-->
                                    <!--            target="_blank">Find-->
                                    <!--            Music &amp; Dance Influencers</a>-->
                                    <!--        <a class="related-item" href="/find-influencers/fashion" target="_blank">Find-->
                                    <!--            Fashion Influencers</a>-->
                                    <!--        <a class="related-item" href="/find-influencers/beauty" target="_blank">Find-->
                                    <!--            Beauty Influencers</a>-->
                                    <!--        <a class="related-item" href="/find-influencers/healthcare" target="_blank">Find-->
                                    <!--            Healthcare Influencers</a>-->
                                    <!--        <a class="related-item" href="/top-influencers/in/united-states"-->
                                    <!--            target="_blank">Top-->
                                    <!--            Influencers in United States</a>-->
                                    <!--        <a class="related-item" href="/top-influencers/in/hillsboro-or-united-states"-->
                                    <!--            target="_blank">Top Influencers in Hillsboro, OR, United-->
                                    <!--            States</a>-->
                                    <!--    </div>-->
                                    <!--</div>-->




                                </div> <!-- listing-img ends -->



                            </div><!-- .nk-block -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- content @e -->

        <script>
            var hasInstagramPackage = false;
            var hasUgcPackage = false;
            var hasTiktokPackage = false;
            var hasYoutubePackage = false;
            var hasAmazonPackage = false;

            $('.package-holder').each(function() {
                var platform = $(this).attr('data-platform');


                if (platform.includes('Instagram')) {
                    $(this).attr('data-platform', 'instagram');
                    hasInstagramPackage = true;
                } else if (platform.includes('UGC')) {
                    $(this).attr('data-platform', 'user generated content');
                    hasUgcPackage = true;
                } else if (platform.includes('TikTok')) {
                    $(this).attr('data-platform', 'tiktok');
                    hasTiktokPackage = true;
                } else if (platform.includes('YouTube')) {
                    $(this).attr('data-platform', 'youtube');
                    hasYoutubePackage = true;
                } else if (platform.includes('Amazon')) {
                    $(this).attr('data-platform', 'amazon');
                    hasAmazonPackage = true;
                }
            });

            if (hasInstagramPackage) {
                $('.package-filter-holder').append('<div class="package-filter" data-platform="instagram">Instagram</div>');
            }
            if (hasUgcPackage) {
                $('.package-filter-holder').append(
                    '<div class="package-filter" data-platform="user generated content">UGC</div>');
            }
            if (hasTiktokPackage) {
                $('.package-filter-holder').append('<div class="package-filter" data-platform="tiktok">TikTok</div>');
            }
            if (hasYoutubePackage) {
                $('.package-filter-holder').append('<div class="package-filter" data-platform="youtube">Youtube</div>');
            }
            if (hasAmazonPackage) {
                $('.package-filter-holder').append('<div class="package-filter" data-platform="amazon">Amazon</div>');
            }


            $('.package-filter').click(function() {
                let plat = $(this).data('platform');
                $('.package-filter').removeClass('package-filter-active');
                $(this).addClass('package-filter-active');
                $('.package-holder').show();
                if (plat !== 'all') $(`.package-holder[data-platform!="${plat}"]`).hide();
            });
        </script>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\collab\resources\views/influencer-details.blade.php ENDPATH**/ ?>