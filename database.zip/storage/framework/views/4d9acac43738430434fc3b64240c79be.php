  <!-- App Settings FAB -->

  <!-- jQuery -->

  <!-- Bootstrap -->
  <script src="<?php echo e(url('assets/vendor/popper.min.js')); ?>"></script>
  <script src="<?php echo e(url('assets/vendor/bootstrap.min.js')); ?>"></script>

  <!-- DOM Factory -->
  <script src="<?php echo e(url('assets/vendor/dom-factory.js')); ?>"></script>

  <!-- MDK -->
  <script src="<?php echo e(url('assets/vendor/material-design-kit.js')); ?>"></script>

  <!-- App -->
  <script src="<?php echo e(url('assets/js/dropdown.js')); ?>"></script>
  <script src="<?php echo e(url('assets/js/sidebar-mini.js')); ?>"></script>
  <script src="<?php echo e(url('assets/js/app.js')); ?>"></script>

  <!-- Flatpickr -->
  <script src="<?php echo e(url('assets/vendor/flatpickr/flatpickr.min.js')); ?>"></script>
  <script src="<?php echo e(url('assets/js/flatpickr.js')); ?>"></script>

  <!-- Global Settings -->
  <script src="<?php echo e(url('assets/js/settings.js')); ?>"></script>

  <!-- Moment.js -->
  <script src="<?php echo e(url('assets/vendor/moment.min.js')); ?>"></script>

  <!-- FullCalendar -->
  <script src="<?php echo e(url('assets/vendor/fullcalendar/fullcalendar.min.js')); ?>"></script>
  
  </body>

  </html>
<?php /**PATH C:\xampp\htdocs\taskministries\resources\views/admin/layout/footer.blade.php ENDPATH**/ ?>