
<?php $__env->startPush('title'); ?>
    <title>Shop</title>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('admin-section'); ?>
    <!-- Header Layout Content -->
    <div class="mdk-header-layout__content mdk-header-layout__content--fullbleed mdk-header-layout__content--scrollable page"
        style="padding-top: 60px;">


        <div class="page__heading border-bottom">
            <div class="container-fluid page__container d-flex align-items-center">
                <h1 class="mb-0">My Courses</h1>
                <a href="<?php echo e(route('add.shop')); ?>" class="btn btn-success ml-auto"><i class="material-icons">add</i> New
                    Material</a>
            </div>
        </div>

        <div class="container-fluid page__container">

            <form action="#" class="mb-3 border-bottom pb-3">
                <div class="d-flex">
                    <div class="search-form mr-3 search-form--light">
                        <input type="text" id="searchInput" class="form-control" placeholder="Search courses"
                            id="searchSample02">
                        <button class="btn" type="button"><i class="material-icons">search</i></button>
                    </div>
                </div>
            </form>
            <div class="d-flex align-items-center justify-content-around flex-wrap">
                <?php $__currentLoopData = $shop; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3">
                        <div class="card card__course">
                            <div
                                class="card-header card-header-large card-header-dark bg-dark d-flex justify-content-center">
                                <span
                                    class="card-header__title  justify-content-center align-self-center d-flex flex-column">
                                    <span><img src="<?php echo e(url('assets/images/' . $row->image)); ?>" class="mb-1"
                                            style="width:100%;" alt="image"></span>
                                </span>
                            </div>
                            <div class="p-3">
                                <div class="mb-2">
                                    <h4 class="course__title"><?php echo e($row->title); ?></h4>
                                    <div class="mr-2">
                                        <?php echo e($row->description); ?>

                                    </div>
                                </div>
                                <div class="d-flex align-items-center">
                                    <strong class="h4 m-0">&dollar;<?php echo e($row->price); ?></strong>
                                </div>
                                <a href="<?php echo e(route('edit.shop', ['id' => $row->id])); ?>" class="btn btn-primary ml-auto"><i
                                        class="material-icons">edit</i></a>
                                <a href="#" data-toggle="modal" class="btn btn-danger ml-auto"
                                    data-target="#delete-modal<?php echo e($row->id); ?>"><i class="material-icons">delete</i></a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <hr>

        </div>


    </div>
    <!-- // END header-layout__content -->

    </div>
    <!-- // END header-layout -->

    </div>
    <!-- // END drawer-layout__content -->

    <?php if (isset($component)) { $__componentOriginal5dbcd2c5f624951ffc95c729c55bdb11 = $component; } ?>
<?php $component = App\View\Components\AdminSidebar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminSidebar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5dbcd2c5f624951ffc95c729c55bdb11)): ?>
<?php $component = $__componentOriginal5dbcd2c5f624951ffc95c729c55bdb11; ?>
<?php unset($__componentOriginal5dbcd2c5f624951ffc95c729c55bdb11); ?>
<?php endif; ?>
    </div>
    <!-- // END drawer-layout -->
    <?php $__currentLoopData = $shop; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <!-- Add New Event MODAL -->
        <div class="modal fade" id="delete-modal<?php echo e($row->id); ?>" tabindex="-1">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header pr-4 pl-4 border-bottom-0 d-block">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        <h4 class="modal-title">Are You Sure You Want to delete <br /> <?php echo e($row->title); ?>?</h4>
                    </div>
                    <div class="modal-body pt-3 pr-4 pl-4">
                    </div>
                    <div class="text-right pb-4 pr-4">
                        <button type="button" class="btn btn-light" data-dismiss="modal">No</button>
                        <a href="<?php echo e(route('delete.shop', ['id' => $row->id])); ?>" class="btn btn-danger">Yes</a>
                    </div>
                </div> <!-- end modal-content-->
            </div> <!-- end modal dialog-->
        </div>
        <!-- end modal-->
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\taskministries\resources\views/admin/shop.blade.php ENDPATH**/ ?>