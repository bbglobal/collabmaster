
<?php $__env->startSection('title', 'Invoice'); ?>

<?php $__env->startPush('plugin-styles'); ?>
    <link href="<?php echo e(asset('admin/assets/plugins/datatables-net-bs5/dataTables.bootstrap5.css')); ?>" rel="stylesheet" />
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-6 grid-margin stretch-card">
      <div class="card">
        <div class="card-body">
          <h4 class="card-title">Invoice</h4>
          <br>
          
          
            <div class="mb-3">
              <label for="name" class="form-label">Full Name: <?php if(!empty($order)): ?> <?php echo e($order->full_name); ?> <?php endif; ?></label>
            </div>

            <div class="mb-3">
                <label for="name" class="form-label">Address: <?php if(!empty($order)): ?> <?php echo e($order->address); ?> <?php endif; ?></label>
              </div>

              <div class="mb-3">
                <label for="name" class="form-label">Description: <?php if(!empty($order)): ?> <?php echo e($order->description); ?> <?php endif; ?></label>
              </div>

              <div class="mb-3">
                <label for="name" class="form-label">Package Content Type: <?php if(!empty($order)): ?> <?php echo e($order->package_content_type); ?> <?php endif; ?></label>
              </div>

              <div class="mb-3">
                <label for="name" class="form-label">Price: <?php if(!empty($order)): ?> <?php echo e($order->price); ?> <?php endif; ?></label>
              </div>

              <div class="mb-3">
                <label for="name" class="form-label">Delivery Status: <?php if(!empty($order)): ?> <?php echo e($order->status); ?> <?php endif; ?></label>
              </div>
             
          </form>
        </div>
      </div>
    </div>
    
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('plugin-scripts'); ?>
    <script src="<?php echo e(asset('admin/assets/plugins/datatables-net/jquery.dataTables.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/plugins/datatables-net-bs5/dataTables.bootstrap5.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('custom-scripts'); ?>
    <script src="<?php echo e(asset('admin/assets/js/data-table.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\collab\resources\views/admin/pages/order/invoice.blade.php ENDPATH**/ ?>