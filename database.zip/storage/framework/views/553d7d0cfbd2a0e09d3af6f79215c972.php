
<?php $__env->startSection('title', 'SubAdmins'); ?>

<?php $__env->startPush('plugin-styles'); ?>
    <link href="<?php echo e(asset('admin/assets/plugins/datatables-net-bs5/dataTables.bootstrap5.css')); ?>" rel="stylesheet" />
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-6 grid-margin stretch-card">
      <div class="card">
        <div class="card-body">
          <h4 class="card-title">SubAdmin</h4>
          <br>
          
          <form id="signupForm" action="<?php echo e(route('admin.store.subadmin')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
              <label for="name" class="form-label">Name</label>
              <input id="name" class="form-control" name="name" type="text">
              <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
            </div>
              <div class="mb-3">
                <label for="name" class="form-label">Email</label>
                <input id="name" class="form-control" name="email" type="text">
                <span class="text-danger"><?php echo e($errors->first('email')); ?></span>

              </div>
              <div class="mb-3">
                <label for="name" class="form-label">Password</label>
                <input id="name" class="form-control" name="password" type="password">
                <span class="text-danger"><?php echo e($errors->first('password')); ?></span>

              </div>
           
            
            <input class="btn btn-primary" type="submit" value="Submit">
          </form>
        </div>
      </div>
    </div>
    
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('plugin-scripts'); ?>
    <script src="<?php echo e(asset('admin/assets/plugins/datatables-net/jquery.dataTables.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/plugins/datatables-net-bs5/dataTables.bootstrap5.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('custom-scripts'); ?>
    <script src="<?php echo e(asset('admin/assets/js/data-table.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/collabma/collabmaster/resources/views/admin/pages/subadmin/add.blade.php ENDPATH**/ ?>