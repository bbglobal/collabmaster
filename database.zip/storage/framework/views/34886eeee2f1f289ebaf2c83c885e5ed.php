<?php echo e($slot); ?>

<?php /**PATH /home/collabma/collabmaster/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>