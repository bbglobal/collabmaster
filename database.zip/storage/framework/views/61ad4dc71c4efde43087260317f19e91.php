
<?php $__env->startPush('title'); ?>
    <title>Contact Student</title>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('admin-section'); ?>
    <!-- Header Layout Content -->
    <div class="mdk-header-layout__content mdk-header-layout__content--fullbleed mdk-header-layout__content--scrollable page"
        style="padding-top: 60px;">


        <div class="page__heading border-bottom">
            <div class="container-fluid page__container d-flex align-items-center">
                <h1 class="mb-0">Contact Student</h1>
            </div>
        </div>

        <div class="container-fluid page__container">

            <?php if($message = Session::get('success')): ?>
                <div class="alert alert-soft-success d-flex" role="alert">
                    <i class="material-icons mr-3">check_circle</i>
                    <div class="text-body">
                        <?php echo e($message); ?>

                    </div>
                </div>
            <?php endif; ?>
            <div class="card card-form">
                <div class="row no-gutters">
                    <div class="col-lg-12 card-form__body card-body">
                        <form method="post" action="<?php echo e(route('contact.student', ['id' => $students->id])); ?>" class="row"
                            enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="form-group col-6">
                                <label for="subject">Subject:</label>
                                <input type="text" name="subject" class="form-control" id="subject"
                                    placeholder="Subject" value="<?php echo e(old('subject')); ?>">
                                <span class="text-danger">
                                    <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </span>
                            </div>
                            <div class="form-group col-6">
                                <label for="attachements">Attachments:</label>
                                <input type="file" name="attachment" class="form-control" id="attachements"
                                    value="<?php echo e(old('attachment')); ?>">
                                <span class="text-danger">
                                    <?php $__errorArgs = ['attachment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </span>
                            </div>
                            <div class="form-group col-12">
                                <label for="body">Body:</label>
                                <textarea class="form-control" name="body" id="body" placeholder="Body" rows="10"></textarea>
                                <span class="text-danger">
                                    <?php $__errorArgs = ['body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </span>
                            </div>
                            <button type="submit" class="btn btn-success">Contact
                                Student</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <!-- // END header-layout__content -->

    </div>
    <!-- // END header-layout -->

    </div>
    <!-- // END drawer-layout__content -->

    <?php if (isset($component)) { $__componentOriginal652ab7bc66b9ed44ea5d06dac129feb9 = $component; } ?>
<?php $component = App\View\Components\TeacherSidebar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('teacher-sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\TeacherSidebar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal652ab7bc66b9ed44ea5d06dac129feb9)): ?>
<?php $component = $__componentOriginal652ab7bc66b9ed44ea5d06dac129feb9; ?>
<?php unset($__componentOriginal652ab7bc66b9ed44ea5d06dac129feb9); ?>
<?php endif; ?>
    </div>
    <!-- // END drawer-layout -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\taskministries\resources\views/teacher/contact.blade.php ENDPATH**/ ?>