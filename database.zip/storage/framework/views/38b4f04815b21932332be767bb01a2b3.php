
<?php $__env->startPush('title'); ?>
    <title>Courses</title>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('admin-section'); ?>
    <!-- Header Layout Content -->
    <div class="mdk-header-layout__content mdk-header-layout__content--fullbleed mdk-header-layout__content--scrollable page"
        style="padding-top: 60px;">


        <div class="page__heading border-bottom">
            <div class="container-fluid page__container d-flex align-items-center">
                <h1 class="mb-0">My Courses</h1>
            </div>
        </div>

        <div class="container-fluid page__container">

            <form action="#" class="mb-3 border-bottom pb-3">
                <div class="d-flex">
                    <div class="search-form mr-3 search-form--light">
                        <input type="text" class="form-control" placeholder="Search courses" id="searchSample02">
                        <button class="btn" type="button"><i class="material-icons">search</i></button>
                    </div>
                </div>
            </form>
            <div class="d-flex align-items-center justify-content-around flex-wrap">
                <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card pt-3" style="width: 18rem;">
                        <img class="card-img-top" src="<?php echo e(url('assets/images/' . $row->course_image)); ?>"
                            alt="Card image cap">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($row->category); ?></h5>
                            <small>
                                with
                                <i class="fa fa-user"></i>
                                <?php echo e($row->level); ?> <?php echo e($row->first_name); ?> <?php echo e($row->last_name); ?>

                            </small>
                            <p class="card-text"><?php echo e($row->sub_title); ?></p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <hr>

        </div>


    </div>
    <!-- // END header-layout__content -->

    </div>
    <!-- // END header-layout -->

    </div>
    <!-- // END drawer-layout__content -->

    <?php if (isset($component)) { $__componentOriginal652ab7bc66b9ed44ea5d06dac129feb9 = $component; } ?>
<?php $component = App\View\Components\TeacherSidebar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('teacher-sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\TeacherSidebar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal652ab7bc66b9ed44ea5d06dac129feb9)): ?>
<?php $component = $__componentOriginal652ab7bc66b9ed44ea5d06dac129feb9; ?>
<?php unset($__componentOriginal652ab7bc66b9ed44ea5d06dac129feb9); ?>
<?php endif; ?>
    </div>
    <!-- // END drawer-layout -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\taskministries\resources\views/teacher/courses.blade.php ENDPATH**/ ?>