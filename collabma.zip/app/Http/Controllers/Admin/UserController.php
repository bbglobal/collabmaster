<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use Validator;

class UserController extends Controller
{
    //
    public function brand_view(){
        $brands = User::where('role','brand')->get();
        // dd($users);
        return view('admin.pages.user.brand_table',compact('brands'));
    }

    public function creator_view(){
        $creators = User::where('role','creator')->get();
        // dd($users);
        return view('admin.pages.user.creator_table',compact('creators'));
    }

    public function brand_status($id){
        $user = User::find($id);
        return view('admin.pages.user.change_status',compact('user'));
    }

    public function brand_details($id){
        $user = User::with('brand')->find($id);
        // dd($user);
        return view('admin.pages.user.brand_details',compact('user'));
    }

    public function creator_status($id){
        $user = User::find($id);
        return view('admin.pages.user.creator_status',compact('user'));
    }

    public function creator_details($id){
        $user = User::with('creator')->find($id);
        // dd($user);
        return view('admin.pages.user.creator_details',compact('user'));
    }

    public function brand_status_update(Request $req)
    {
        $controlls = $req->all();
        $rules = array(
            "status" => "required"
        );

        $validator = Validator::make($controlls, $rules);
        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator)->withInput($controlls);
        } else {
            $status = User::find($req->id);
            $status->status = $req->status;
            $status->save();

            return redirect()->route('admin.brand')->with(['success' => "Status Successfully Updated"]);
        }
    }

    public function creator_status_update(Request $req)
    {
        $controlls = $req->all();
        $rules = array(
            "status" => "required"
        );

        $validator = Validator::make($controlls, $rules);
        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator)->withInput($controlls);
        } else {
            $status = User::find($req->id);
            $status->status = $req->status;
            $status->save();

            return redirect()->route('admin.creator')->with(['success' => "Status Successfully Updated"]);
        }
    }
}
