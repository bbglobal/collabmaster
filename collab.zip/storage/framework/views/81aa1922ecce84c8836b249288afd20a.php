
<?php $__env->startSection('title', 'Staff'); ?>

<?php $__env->startPush('plugin-styles'); ?>
    <link href="<?php echo e(asset('admin/assets/plugins/datatables-net-bs5/dataTables.bootstrap5.css')); ?>" rel="stylesheet" />
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>
        <div class="col-lg-6 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">Staff</h4>
                    <br>
                    
                    <form id="signupForm" action="<?php echo e(route('admin.store.staff')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="name" class="form-label">Name</label>
                            <select class="form-select" name="subadmin_id" id="ageSelect" required>
                                <option selected disabled>Select your SubAdmin</option>
                                <?php $__currentLoopData = $subadmins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subadmin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($subadmin->id); ?>">
                                        <?php echo e($subadmin->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </select>
                            <span class="text-danger"><?php echo e($errors->first('subadmin_id')); ?></span>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Permission</label>
                            <div>
                                <div class="form-check form-check-inline">
                                    <input type="checkbox" name="permission[]" class="form-check-input" id="checkInline1"
                                    value="Sales">
                                    <label class="form-check-label" for="checkInline1">
                                        Sales
                                    </label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input type="checkbox" name="permission[]" class="form-check-input" id="checkInline2"
                                    value="Content Managment">
                                    <label class="form-check-label" for="checkInline2">
                                        Content Managment
                                    </label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input type="checkbox" name="permission[]" class="form-check-input" id="checkInline3"
                                    value="Dispute">
                                    <label class="form-check-label" for="checkInline3">
                                        Dispute
                                    </label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input type="checkbox" name="permission[]" class="form-check-input" id="checkInline4"
                                    value="Teams">
                                    <label class="form-check-label" for="checkInline4">
                                        Teams
                                    </label>
                                </div>
                            </div>
                        </div>



                        <input class="btn btn-primary" type="submit" value="Submit">
                    </form>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('plugin-scripts'); ?>
    <script src="<?php echo e(asset('admin/assets/plugins/datatables-net/jquery.dataTables.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/plugins/datatables-net-bs5/dataTables.bootstrap5.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('custom-scripts'); ?>
    <script src="<?php echo e(asset('admin/assets/js/data-table.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\collab\resources\views/admin/pages/staff/add.blade.php ENDPATH**/ ?>