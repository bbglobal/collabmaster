
<?php $__env->startPush('title'); ?>
    <title>Add Shop</title>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('admin-section'); ?>
    <!-- Header Layout Content -->
    <div class="mdk-header-layout__content mdk-header-layout__content--fullbleed mdk-header-layout__content--scrollable page"
        style="padding-top: 60px;">


        <div class="page__heading border-bottom">
            <div class="container-fluid page__container d-flex align-items-center">
                <h1 class="mb-0">Add Material</h1>
            </div>
        </div>

        <div class="container-fluid page__container">
            <?php if($message = Session::get('success')): ?>
                <div class="alert alert-soft-success d-flex" role="alert">
                    <i class="material-icons mr-3">check_circle</i>
                    <div class="text-body">
                        <?php echo e($message); ?>

                    </div>
                </div>
            <?php endif; ?>
            <div class="card card-form">
                <div class="row no-gutters">
                    <div class="col-lg-12 card-form__body card-body">
                        <form method="post" action="<?php echo e(route('add.shops')); ?>" class="row" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="form-group col-12">
                                <label for="img">Image:</label>
                                <input type="file" name="image" class="form-control" id="img"
                                    value="<?php echo e(old('image')); ?>">
                            </div>
                            <div class="form-group col-6">
                                <label for="title">Title:</label>
                                <input type="text" name="title" class="form-control" id="title" placeholder="Title"
                                    value="<?php echo e(old('title')); ?>">
                                <span class="text-danger">
                                    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </span>
                            </div>
                            <div class="form-group col-6">
                                <label for="price">Price:</label>
                                <input id="price" name="price" type="number" class="form-control" placeholder="Price"
                                    value="<?php echo e(old('price')); ?>">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                            </div>
                            <div class="form-group col-12">
                                <label for="material">Material:</label>
                                <input type="file" name="material" class="form-control" id="material"
                                    value="<?php echo e(old('material')); ?>">
                                <span class="text-danger">
                                    <?php $__errorArgs = ['material'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </span>
                            </div>
                            <div class="form-group col-12">
                                <label for="description">Short Description:</label>
                                <textarea name="description" class="form-control" id="description" cols="30" rows="5"
                                    placeholder="Short Description">
                                    <?php echo e(old('description')); ?>

                                </textarea>
                            </div>
                            <button type="submit" class="btn btn-success"><i class="material-icons">add</i>Add
                                Material</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>


    </div>
    <!-- // END header-layout__content -->

    </div>
    <!-- // END header-layout -->

    </div>
    <!-- // END drawer-layout__content -->

    <?php if (isset($component)) { $__componentOriginal5dbcd2c5f624951ffc95c729c55bdb11 = $component; } ?>
<?php $component = App\View\Components\AdminSidebar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminSidebar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5dbcd2c5f624951ffc95c729c55bdb11)): ?>
<?php $component = $__componentOriginal5dbcd2c5f624951ffc95c729c55bdb11; ?>
<?php unset($__componentOriginal5dbcd2c5f624951ffc95c729c55bdb11); ?>
<?php endif; ?>
    </div>
    <!-- // END drawer-layout -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\taskministries\resources\views/admin/add-shop.blade.php ENDPATH**/ ?>