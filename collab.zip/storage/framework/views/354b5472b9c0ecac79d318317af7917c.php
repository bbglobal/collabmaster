
<?php $__env->startPush('title'); ?>
    <title>Contact</title>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('admin-section'); ?>
    <!-- Header Layout Content -->
    <div class="mdk-header-layout__content mdk-header-layout__content--fullbleed mdk-header-layout__content--scrollable page"
        style="padding-top: 60px;">


        <div class="page__heading border-bottom">
            <div class="container-fluid page__container d-flex align-items-center">
                <h1 class="mb-0">Contact Data</h1>
            </div>
        </div>

        <div class="container-fluid page__container">
            <div class="card card-form">
                <div class="row no-gutters">
                    <div class="col-lg-12 card-form__body">

                        <div class="table-responsive border-bottom" data-toggle="lists"
                            data-lists-values='["js-lists-values-employee-name"]'>

                            <div class="search-form search-form--light m-3">
                                <input type="text" id="searchInput" class="form-control search" placeholder="Search">
                                <button class="btn" type="button"><i class="material-icons">search</i></button>
                            </div>

                            <table class="table mb-0 thead-border-top-0">
                                <thead>
                                    <tr>
                                        <th>Id</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Contact</th>
                                        <th>BIO</th>
                                        <th>Level</th>
                                        <th>Category</th>
                                        <th>Message</th>
                                    </tr>
                                </thead>
                                <tbody class="list" id="staff02">
                                    <?php $__currentLoopData = $hub; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <span><?php echo e($row->id); ?></span>
                                            </td>
                                            <td>
                                                <span class="js-lists-values-employee-name"><?php echo e($row->name); ?></span>
                                            </td>
                                            <td>
                                                <span class="js-lists-values-employee-name">
                                                    <a href="mailto:<?php echo e($row->email); ?>" style="color:#333;"><?php echo e($row->email); ?></a>
                                                </span>
                                            </td>
                                            <td>
                                                <span class="js-lists-values-employee-name"><?php echo e($row->contact); ?></span>
                                            </td>
                                            <?php if($row->role == 'instructor'): ?>
                                                <td>
                                                    <a href="<?php echo e(url('assets/images/apostolicHub/'.$row->bio)); ?>" class="js-lists-values-employee-name btn btn-primary" target="_blank">View Bio</a>
                                                </td>
                                                <td>
                                                    <span class="js-lists-values-employee-name"><?php echo e($row->level); ?></span>
                                                </td>
                                            <?php else: ?>
                                                <td>
                                                    <span class="js-lists-values-employee-name">-</span>
                                                </td>
                                                <td>
                                                    <span class="js-lists-values-employee-name">-</span>
                                                </td>
                                            <?php endif; ?>
                                            <td>
                                                <span class="js-lists-values-employee-name"><?php echo e($row->role); ?></span>
                                            </td>
                                            <td>
                                                <span class="js-lists-values-employee-name"><?php echo e($row->message); ?></span>
                                            </td>
                                            <td>
                                                <div class="dropdown ml-auto">
                                                    <a href="#" class="dropdown-toggle text-muted" data-caret="false"
                                                        data-toggle="dropdown">
                                                        <i class="material-icons">more_vert</i>
                                                    </a>
                                                    <div class="dropdown-menu dropdown-menu-right">
                                                        <a class="dropdown-item text-danger" data-toggle="modal"
                                                            data-target="#delete-modal<?php echo e($row->id); ?>"
                                                            href="">Delete</a>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>


    </div>
    <!-- // END header-layout__content -->

    </div>
    <!-- // END header-layout -->

    </div>
    <!-- // END drawer-layout__content -->

    <?php if (isset($component)) { $__componentOriginal5dbcd2c5f624951ffc95c729c55bdb11 = $component; } ?>
<?php $component = App\View\Components\AdminSidebar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminSidebar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5dbcd2c5f624951ffc95c729c55bdb11)): ?>
<?php $component = $__componentOriginal5dbcd2c5f624951ffc95c729c55bdb11; ?>
<?php unset($__componentOriginal5dbcd2c5f624951ffc95c729c55bdb11); ?>
<?php endif; ?>
    </div>
    <!-- // END drawer-layout -->

    <?php $__currentLoopData = $hub; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <!-- Add New Event MODAL -->
        <div class="modal fade" id="delete-modal<?php echo e($row->id); ?>" tabindex="-1">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header pr-4 pl-4 border-bottom-0 d-block">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        <h4 class="modal-title">Are You Sure You Want to delete <br />
                            <?php echo e($row->name); ?>?</h4>
                    </div>
                    <div class="modal-body pt-3 pr-4 pl-4">
                    </div>
                    <div class="text-right pb-4 pr-4">
                        <button type="button" class="btn btn-light" data-dismiss="modal">No</button>
                        <a href="<?php echo e(route('hub.delete', ['id' => $row->id])); ?>" class="btn btn-danger">Yes</a>
                    </div>
                </div> <!-- end modal-content-->
            </div> <!-- end modal dialog-->
        </div>
        <!-- end modal-->
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <script>
        // Get the input element and table body
        var input = document.getElementById("searchInput");
        var tableBody = document.getElementById("staff02");

        // Add an event listener to the search input
        input.addEventListener("input", function() {
            var searchQuery = input.value.toLowerCase();

            // Get all rows in the table
            var rows = tableBody.getElementsByTagName("tr");

            // Loop through the rows and hide those that don't match the search query
            for (var i = 0; i < rows.length; i++) {
                var row = rows[i];
                var cells = row.getElementsByTagName("td");
                var found = false;

                for (var j = 0; j < cells.length; j++) {
                    var cell = cells[j];
                    if (cell) {
                        var text = cell.innerText.toLowerCase();
                        if (text.indexOf(searchQuery) > -1) {
                            found = true;
                            break;
                        }
                    }
                }

                if (found) {
                    row.style.display = "";
                } else {
                    row.style.display = "none";
                }
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\taskministries\resources\views/admin/hub.blade.php ENDPATH**/ ?>