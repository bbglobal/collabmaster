
<?php $__env->startSection('title', 'Brands'); ?>

<?php $__env->startPush('plugin-styles'); ?>
    <link href="<?php echo e(asset('admin/assets/plugins/datatables-net-bs5/dataTables.bootstrap5.css')); ?>" rel="stylesheet" />
<?php $__env->stopPush(); ?>



<?php $__env->startSection('content'); ?>
    <nav class="page-breadcrumb">
        
        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>
    </nav>




    <div class="row">

        
        <div class="col-md-12 grid-margin stretch-card">

            <div class="card">
                <div class="card-body">
                    <h6 class="card-title">Brands</h6>
                    <p class="text-muted mb-3"><a href="https://datatables.net/" target="_blank"></a></p>
                    <div class="table-responsive">
                        <table id="dataTableExample" class="table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Full Name</th>
                                    <th>Brand Name</th>
                                    <th>Email</th>
                                    <th>Phone Number</th>
                                    <th>Found Us</th>
                                    <th>Role</th>
                                    <th>Status</th>

                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($brand->id); ?></td>
                                        <td><?php echo e($brand->full_name); ?></td>
                                        <td><?php echo e($brand->brand_name); ?></td>
                                        <td><?php echo e($brand->email); ?></td>
                                        <td><?php echo e($brand->phone_number); ?></td>
                                        <td><?php echo e($brand->found_us); ?></td>
                                        <td><?php echo e($brand->role); ?></td>
                                        <td>
                                            <?php if($brand->status == 'Active'): ?>
                                            <span class="text-success">
                                                Active
                                            </span>
                                            <?php else: ?>
                                            <span class="text-danger">
                                                DeActive
                                            </span>
                                            <?php endif; ?>
                                         </td>

                                        <td>
                                            <a class="edit"
                                                href="<?php echo e(route('admin.brand.status',['id'=>$brand->id])); ?>">
                                                <i class="link-icon" data-feather="edit"></i>

                                            </a>
                                            <a class="edit"
                                                href="<?php echo e(route('admin.brand.details',['id'=>$brand->id])); ?>">
                                                <i class="link-icon" data-feather="eye"></i>

                                            </a>
                                            
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('plugin-scripts'); ?>
    <script src="<?php echo e(asset('admin/assets/plugins/datatables-net/jquery.dataTables.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/plugins/datatables-net-bs5/dataTables.bootstrap5.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('custom-scripts'); ?>
    <script src="<?php echo e(asset('admin/assets/js/data-table.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\collabmaster\resources\views/admin/pages/user/brand_table.blade.php ENDPATH**/ ?>