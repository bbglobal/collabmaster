<?php $__env->startSection('title', 'Details'); ?>

<?php $__env->startPush('plugin-styles'); ?>
    <link href="<?php echo e(asset('admin/assets/plugins/datatables-net-bs5/dataTables.bootstrap5.css')); ?>" rel="stylesheet" />
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-6 grid-margin stretch-card">
      <div class="card">
        <div class="card-body">
          <h4 class="card-title">Details</h4>
          <br>
          
          <form id="signupForm" action="<?php echo e(route('admin.store.subadmin')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
              <label for="name" class="form-label">Industry: <?php if(!empty($user->brand)): ?> <?php echo e($user->brand->industry); ?> <?php endif; ?></label>
            </div>

            <div class="mb-3">
                <label for="name" class="form-label">Categories: <?php if(!empty($user->brand)): ?> <?php echo e($user->brand->categories); ?> <?php endif; ?></label>
              </div>

              <div class="mb-3">
                <label for="name" class="form-label">Familiarity: <?php if(!empty($user->brand)): ?> <?php echo e($user->brand->familiarity); ?> <?php endif; ?></label>
              </div>

              <div class="mb-3">
                <label for="name" class="form-label">Platforms: <?php if(!empty($user->brand)): ?> <?php echo e($user->brand->platforms); ?> <?php endif; ?></label>
              </div>

              <div class="mb-3">
                <label for="name" class="form-label">Need: <?php if(!empty($user->brand)): ?> <?php echo e($user->brand->need); ?> <?php endif; ?></label>
              </div>

              <div class="mb-3">
                <label for="name" class="form-label">Content: <?php if(!empty($user->brand)): ?> <?php echo e($user->brand->content); ?> <?php endif; ?></label>
              </div>

          </form>
        </div>
      </div>
    </div>

  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('plugin-scripts'); ?>
    <script src="<?php echo e(asset('admin/assets/plugins/datatables-net/jquery.dataTables.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/plugins/datatables-net-bs5/dataTables.bootstrap5.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('custom-scripts'); ?>
    <script src="<?php echo e(asset('admin/assets/js/data-table.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\collab\resources\views/admin/pages/user/brand_details.blade.php ENDPATH**/ ?>