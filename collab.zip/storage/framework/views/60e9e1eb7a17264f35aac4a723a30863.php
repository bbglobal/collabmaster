
<?php $__env->startSection('title', 'Status'); ?>

<?php $__env->startPush('plugin-styles'); ?>
    <link href="<?php echo e(asset('admin/assets/plugins/datatables-net-bs5/dataTables.bootstrap5.css')); ?>" rel="stylesheet" />
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-6 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">Status Changes</h4>
                    <br>
                    
                    <form id="signupForm" action="<?php echo e(route('admin.status.update')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" <?php if(!empty($user)): ?> value="<?php echo e($user->id); ?>" <?php endif; ?>>

                        <div class="mb-3">
                            <label for="ageSelect" class="form-label">Status</label>
                            <select class="form-select" name="status" id="ageSelect" required>
                                <option selected disabled>Select your Status</option>
                                <option value="Active" <?php if(!empty($user) && $user->status == 'Active'): ?> selected <?php endif; ?>>Active</option>
                                <option value="DeActive" <?php if(!empty($user) && $user->status == 'DeActive'): ?> selected <?php endif; ?>>DeActive</option>

                            </select>
                            <span class="text-danger"><?php echo e($errors->first('status')); ?></span>

                        </div>
                       


                        <input class="btn btn-primary" type="submit" value="Submit">
                    </form>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('plugin-scripts'); ?>
    <script src="<?php echo e(asset('admin/assets/plugins/datatables-net/jquery.dataTables.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/plugins/datatables-net-bs5/dataTables.bootstrap5.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('custom-scripts'); ?>
    <script src="<?php echo e(asset('admin/assets/js/data-table.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\collabmaster\resources\views/admin/pages/user/change_status.blade.php ENDPATH**/ ?>