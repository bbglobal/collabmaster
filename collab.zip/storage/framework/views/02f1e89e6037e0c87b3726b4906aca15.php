

<?php $__env->startPush('footer-style'); ?>
    <style>
        .nk-footer {
            display: none;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main-section'); ?>
    <?php if($message = Session::get('message')): ?>
        <div id="msg-holder">
            <div id="msg-holder-row">
                <img src="https://d5ik1gor6xydq.cloudfront.net/websiteImages/creatorMarketplace/succ.svg" class="succ-err-msg-img" id="msg-img-succ">
                <div id="msg"><?php echo e($message); ?></div>
            </div>
        </div>
    <?php endif; ?>
    <div class="nk-content main-outer-container">
        <div class="container-fluid">
            <div class="nk-content-inner">
                <div class="nk-content-body">
                    <div class="nk-content-wrap">


                        <div class="nk-block nk-block-middle nk-auth-body wide-xs pt-0">
                            
                            <div class="card mt-5">
                                <div class="card-inner card-inner p-0">
                                    <div class="top-btn-holder">
                                        
                                        <div class="step-holder">9/9</div>
                                    </div>
                                    <div class="nk-block-head">
                                        <div class="nk-block-head-content">
                                            <h4 class="nk-block-title"><b>We sent an otp to
                                                    <?php echo e(Auth::user()->phone_number); ?>. Check
                                                    your inbox and enter the
                                                    otp to verify your phone number.</b></h4>
                                        </div>
                                    </div>

                                    <form method="POST" action="<?php echo e(route('create.page', ['id' => 12])); ?>" id="form">
                                        <?php echo csrf_field(); ?>
                                        <div class="form-group mb-3">
                                            <input id="otp" type="text" class="form-control form-control-lg"
                                                name="token" autofocus placeholder="One Time Password" required>
                                        </div>
                                        <div class="form-group mb-3">
                                            <button type="submit" class="btn btn-lg btn-secondary btn-block"
                                                id="primary">Continue</button>

                                            <button class="btn btn-lg btn-secondary btn-block d-none" id="loading"
                                                type="button" disabled>
                                                <span class="spinner-border spinner-border-sm" role="status"
                                                    aria-hidden="true"></span>
                                                <span>Loading...</span>
                                            </button>
                                        </div>
                                    </form>

                                    
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- content @e -->

    <script>
        $(document).ready(function() {
            $('#form').submit(() => {
                $('#primary').addClass("d-none");
                $("#loading").removeClass("d-none")
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/collabma/collabmaster/resources/views/creator/otp.blade.php ENDPATH**/ ?>