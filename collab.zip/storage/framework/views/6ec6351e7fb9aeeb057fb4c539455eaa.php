
    <section id="browse-each">
        <iframe src="https://kingdominspirations.org/about-us" height="100vh" width="100%" title="Iframe Example"></iframe>
    </section>

<?php /**PATH C:\xampp\htdocs\taskministries\resources\views/kingdom-inspiration.blade.php ENDPATH**/ ?>