
<?php $__env->startSection('title', 'Orders'); ?>

<?php $__env->startPush('plugin-styles'); ?>
    <link href="<?php echo e(asset('admin/assets/plugins/datatables-net-bs5/dataTables.bootstrap5.css')); ?>" rel="stylesheet" />
<?php $__env->stopPush(); ?>



<?php $__env->startSection('content'); ?>
    <nav class="page-breadcrumb">
        
        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>
    </nav>




    <div class="row">

        
        <div class="col-md-12 grid-margin stretch-card">

            <div class="card">
                <div class="card-body">
                    <h6 class="card-title">Orders</h6>
                    <p class="text-muted mb-3"><a href="https://datatables.net/" target="_blank"></a></p>
                    <div class="table-responsive">
                        <table id="dataTableExample" class="table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Full Name</th>
                                    <th>Address</th>
                                    <th>Description</th>
                                    <th>Package Content Type</th>
                                    <th>Price</th>
                                    <th>Delivery Status</th>
                                    <th>Conformation Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($order->id); ?></td>
                                        <td><?php echo e($order->full_name); ?></td>
                                        <td><?php echo e($order->address); ?></td>
                                        <td><?php echo e($order->description); ?></td>
                                        <td><?php echo e($order->package_content_type); ?></td>
                                        <td><?php echo e($order->price); ?></td>
                                        <td><?php echo e($order->status); ?></td>
                                        <td>
                                            <?php if($order->conformation_status == 'Accepted'): ?>
                                            <span class="text-success">
                                                Accepted
                                            </span>
                                            <?php elseif($order->conformation_status == 'Decline'): ?>
                                            <span class="text-danger">
                                                Decline
                                            </span>
                                            <?php endif; ?>
                                         </td>

                                         <td>
                                            <a class="edit"
                                                href="<?php echo e(route('admin.invoice',['id'=>$order->id])); ?>" target="_blank">
                                                <i class="link-icon" data-feather="eye"></i>

                                            </a>
                                         </td>
                                        </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('plugin-scripts'); ?>
    <script src="<?php echo e(asset('admin/assets/plugins/datatables-net/jquery.dataTables.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/plugins/datatables-net-bs5/dataTables.bootstrap5.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('custom-scripts'); ?>
    <script src="<?php echo e(asset('admin/assets/js/data-table.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\collab\resources\views/admin/pages/order/table.blade.php ENDPATH**/ ?>